    <footer class="footer">
      <div id="js-pageTop" class="page-top">
        <div class="page-top__btn u-hidden-sp">
          <i class="far fa-arrow-alt-circle-up page-top__arrow"></i>
        </div>
      </div>
      <div class="l-footer">
        <p class="copylight"><small>&copy; <?php bloginfo( 'name' ); ?> 2021</small></p>
      </div>
    </footer>
  </div>
  <?php wp_footer(); ?>
</body>
</html>